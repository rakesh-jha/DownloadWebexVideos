﻿using System.Configuration;

namespace WebExDownloadVideo
{
    public class WebExXmlRequest
    {
        string schema_soapenv { get; set; }
        string schema_xsd { get; set; }
        string schema_xsi { get; set; }
        string schema_encodingStyle { get; set; }
        string schema_serv { get; set; }
        string siteId { get; set; }
        string siteName { get; set; }
        string userName { get; set; }
        string password { get; set; }

        public WebExXmlRequest()
        {
            schema_soapenv = ConfigurationManager.AppSettings["soapenv"];
            schema_xsd = ConfigurationManager.AppSettings["xsd"];
            schema_xsi = ConfigurationManager.AppSettings["xsi"];
            schema_encodingStyle = ConfigurationManager.AppSettings["encodingStyle"];
            schema_serv = ConfigurationManager.AppSettings["serv"];
            siteId = ConfigurationManager.AppSettings["SiteId"];
            siteName = ConfigurationManager.AppSettings["SiteName"];
            userName = ConfigurationManager.AppSettings["UserName"];
            password = ConfigurationManager.AppSettings["Password"];
        }
        public string ConstructXMLForStorageAccessTicket()
        {
            return "<?xml version='1.0' encoding='UTF-8'?>\r\n" +
                    "<soapenv:Envelope xmlns:soapenv='" + schema_soapenv + "' xmlns:xsd='" + schema_xsd + "' xmlns:xsi='" + schema_xsi + "'>\r\n" +
                        "<soapenv:Body>\r\n" +
                            "<ns1:getStorageAccessTicket soapenv:encodingStyle='" + schema_encodingStyle + "' xmlns:ns1='NBRStorageService'>\r\n" +
                                "<siteId xsi:type='xsd:long'>" + siteId + "</siteId>\r\n" +
                                "<username xsi:type='xsd:string'>" + userName + "</username>\r\n" +
                                "<password xsi:type='xsd:string'>" + password + "</password>\r\n" +
                            "</ns1:getStorageAccessTicket>\r\n" +
                        "</soapenv:Body>\r\n" +
                    "</soapenv:Envelope>";
        }

        public string ConstructXMLForGettingRecordId(string meetingKey)
        {
            return "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\r\n" +
                    "<serv:message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:serv=\"http://www.webex.com/schemas/2002/06/service\">\r\n" +
                        "<header>\r\n" +
                            "<securityContext>\r\n" +
                                "<webExID>" + userName + "</webExID>\r\n" +
                                "<password>" + password + "</password>\r\n" +
                                "<siteName>" + siteName + "</siteName>\r\n" +
                            "</securityContext>\r\n" +
                        "</header>\r\n" +
                        "<body>\r\n" +
                            "<bodyContent xsi:type=\"java:com.webex.service.binding.ep.LstRecording\">\r\n" +
                                "<sessionKey>" + meetingKey + "</sessionKey>\r\n" +
                                "<hostWebExID>" + userName + "</hostWebExID>\r\n" +
                            "</bodyContent>\r\n" +
                        "</body>\r\n" +
                    "</serv:message>";
        }

        public string ConstructXMLForDownloadingNBRFile(string recordId, string ticket)
        {
            return "<?xml version='1.0' encoding='UTF-8'?>\r\n" +
                    "<soapenv:Envelope xmlns:soapenv='" + schema_soapenv + "' xmlns:xsd='" + schema_xsd + "' xmlns:xsi='" + schema_xsi + "'>\r\n" +
                        "<soapenv:Body>\r\n" +
                            "<ns1:downloadNBRStorageFile soapenv:encodingStyle='" + schema_encodingStyle + "' xmlns:ns1=\"NBRStorageService\">\r\n" +
                                "<siteId xsi:type='xsd:long'>" + siteId + "</siteId>\r\n" +
                                "<recordId xsi:type=\"xsd:long\">" + recordId + "</recordId>\r\n" +
                                "<ticket xsi:type=\"xsd:string\">" + ticket + "</ticket>\r\n" +
                            "</ns1:downloadNBRStorageFile>\r\n" +
                        "</soapenv:Body>\r\n" +
                    "</soapenv:Envelope>";
        }
    }
}
