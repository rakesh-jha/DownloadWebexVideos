﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace WebExDownloadVideo
{
    public class EmailHelper
    {
        public static void SendEmail(string to, string subject, string message, string cc = "", string bcc = "")
        {
            var email = new MailMessage();
            email.To.Add(to);

            email.Subject = subject;
            email.Body = message;
            email.IsBodyHtml = true;

            if (!string.IsNullOrWhiteSpace(cc))
            {
                email.CC.Add(cc);
            }
            if (!string.IsNullOrWhiteSpace(bcc))
            {
                email.Bcc.Add(bcc);
            }

            using (var smtpClient = new SmtpClient())
            {
                smtpClient.Send(email);
            }
        }
    }
}
