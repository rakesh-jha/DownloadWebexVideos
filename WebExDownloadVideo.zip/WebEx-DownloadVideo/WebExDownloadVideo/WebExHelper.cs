﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;

namespace WebExDownloadVideo
{
    public class WebExHelper
    {
        public string GetStorageAccessTicket()
        {
            var apiUrl = ConfigurationManager.AppSettings["NBRAPIUrl"];
            var xml = new WebExXmlRequest().ConstructXMLForStorageAccessTicket();
            var webRequest = System.Net.WebRequest.Create(apiUrl);
            webRequest.Headers.Add("SOAPAction", apiUrl + "/getStorageAccessTicket");
            webRequest.Method = System.Net.WebRequestMethods.Http.Post;
            webRequest.ContentType = "text/xml;charset=utf-8";

            var byteArray = Encoding.UTF8.GetBytes(xml.ToString());
            webRequest.ContentLength = byteArray.Length;

            var dataStream = webRequest.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            var response = webRequest.GetResponse();

            dataStream = response.GetResponseStream();
            var reader = new System.IO.StreamReader(dataStream);
            string rawResponse = reader.ReadToEnd();

            dataStream.Close();
            reader.Close();
            response.Close();

            string result = string.Empty;
            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.LoadXml(rawResponse);

            XmlNodeList ticket = xmlResponse.GetElementsByTagName("ns1:getStorageAccessTicketReturn");
            if (ticket.Count > 0)
            {
                result = ticket[0].InnerText;
            }
            return result;
        }

        public string GetRecordId(string meetingKey)
        {
            var apiUrl = ConfigurationManager.AppSettings["XMLAPIUrl"];
            var xml = new WebExXmlRequest().ConstructXMLForGettingRecordId(meetingKey);
            var webRequest = WebRequest.Create(apiUrl);
            webRequest.Method = WebRequestMethods.Http.Post;
            webRequest.ContentType = "application/x-www-form-urlencoded";

            var byteArray = Encoding.UTF8.GetBytes(xml.ToString());
            webRequest.ContentLength = byteArray.Length;

            var dataStream = webRequest.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            var response = webRequest.GetResponse();

            dataStream = response.GetResponseStream();
            var reader = new System.IO.StreamReader(dataStream);
            string rawResponse = reader.ReadToEnd();

            dataStream.Close();
            reader.Close();
            response.Close();

            string result = string.Empty;
            XmlDocument xmlResponse = new XmlDocument();
            xmlResponse.LoadXml(rawResponse);

            XmlNodeList recordingIds = xmlResponse.GetElementsByTagName("ep:recordingID");
            if (recordingIds.Count > 0)
            {
                result = recordingIds[0].InnerText;
            }
            return result;
        }

        public void DownloadNBRStorageFile(string ticket, string recordId, string meetingKey)
        {
            string filePath = "d:\\WebEx_Videos\\" + meetingKey + ".arf";
            var apiUrl = ConfigurationManager.AppSettings["NBRAPIUrl"];
            var xml = new WebExXmlRequest().ConstructXMLForDownloadingNBRFile(recordId, ticket);
            var webRequest = System.Net.WebRequest.Create(apiUrl);
            webRequest.Headers.Add("SOAPAction", apiUrl + "/downloadNBRStorageFile");
            webRequest.Method = System.Net.WebRequestMethods.Http.Post;
            webRequest.ContentType = "text/xml;charset=utf-8";

            var byteArray = Encoding.UTF8.GetBytes(xml.ToString());
            webRequest.ContentLength = byteArray.Length;

            var dataStream = webRequest.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            var response = webRequest.GetResponse();

            dataStream = response.GetResponseStream();
            StringBuilder sb = new StringBuilder();
            int bytetoread = 10;
            string str = "";
            using (FileStream fs = File.Create(filePath))
            {
                Byte[] buffer = new Byte[1024];

                int read = dataStream.Read(buffer, 0, buffer.Length);

                str = Encoding.UTF8.GetString(buffer);

                buffer = new Byte[200];
                read = dataStream.Read(buffer, 0, buffer.Length);
                str = Encoding.UTF8.GetString(buffer);

                while (read > 0)
                {
                    buffer = new Byte[bytetoread];
                    read = dataStream.Read(buffer, 0, buffer.Length);
                    str = Encoding.UTF8.GetString(buffer);
                    if (str.Contains("<"))
                    {
                        bytetoread = 1;
                    }
                    if (str.Contains(">"))
                    {
                        break;
                    }
                }

                int cnt = 4;
                while (cnt > 0)
                {
                    buffer = new Byte[1];
                    read = dataStream.Read(buffer, 0, buffer.Length);
                    str = Encoding.UTF8.GetString(buffer);
                    cnt--;
                }

                buffer = new Byte[1024];
                read = dataStream.Read(buffer, 0, buffer.Length);
                while (read > 0)
                {
                    fs.Write(buffer, 0, read);
                    buffer = new Byte[1024];
                    read = dataStream.Read(buffer, 0, buffer.Length);
                }
            }
            dataStream.Close();
        }
    }
}
